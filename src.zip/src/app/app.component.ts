import { Component } from '@angular/core';
 declare var google;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {  
  latitude = -2.866667;
  longitude =  -78.933333;
  zoom =16;
  directionsService = new google.maps.DirectionService();
    
  onChoseLocation(event){
    console.log(event);
    this.latitude = event.coords.lat;
    this.longitude = event.coords.lng;
    
  }
  loadMap(){
    const mapEle : HTMLElement = document.getElementById('map');
    
  }
}
